
.. _chart:

Chart
=====

.. module:: pygsheets

.. autoclass:: Chart
   :members:
