
.. _spreadsheet:

Spreadsheet
===========

.. module:: pygsheets

.. autoclass:: Spreadsheet
   :members:
