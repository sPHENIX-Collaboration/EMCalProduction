
.. _datarange:

DataRange
=========

.. module:: pygsheets

.. autoclass:: DataRange
   :members:
