
.. _sheet_api:

Sheet API
=========

.. module:: pygsheets.sheet

.. autoclass:: SheetAPIWrapper
   :members:
